/*!
 * Chiro-Fysio exit-intent pop-up
 * -----------------------------------------------------------------------------
 * Vraagt bezoekers die de site dreigen te verlaten of ze gevonden hebben wat ze
 * zochten. Zo niet, dan tonen we het telefoonnummer en (optioneel) WhatsApp.
 *
 * Geen dependencies, geen tracking cookies. De enige opslag is een
 * localStorage-sleutel om te onthouden dat we de pop-up al getoond hebben,
 * zodat we niemand twee keer lastigvallen.
 */
(function () {
  'use strict';

  /* ==========================================================================
     STANDAARDWAARDEN

     In WordPress hoef je hier niets te wijzigen: alles is aan te passen onder
     Exit-pop-up -> Pop-up instellen. Wat daar is opgeslagen wordt hieronder
     overheen gelegd. Deze waarden gelden dus alleen als terugval, en op de
     demo- en testpagina's die buiten WordPress draaien.
     ========================================================================== */
  var DEFAULTS = {
    // Telefoonnummer van de praktijk, zoals de bezoeker het te zien krijgt.
    // Bevestigd door de praktijk: 024-3558830.
    phoneDisplay: '024 - 355 88 30',

    // Hetzelfde nummer, maar met de landcode in plaats van de nul en zonder
    // spaties. Dat is wat de belknop gebruikt, zodat hij ook werkt als iemand
    // vanaf een mobiel of vanuit het buitenland belt.
    phoneHref: '+31243558830',

    // WhatsApp-nummer van de praktijk, in internationaal formaat zonder + en
    // zonder spaties. Dit is 06-14798722. Laat leeg ('') om de knop te
    // verbergen; een vast 024-nummer werkt namelijk niet op WhatsApp.
    whatsapp: '31614798722',

    // Tekst die alvast in het WhatsApp-bericht staat.
    whatsappText: 'Hallo, ik heb een vraag naar aanleiding van jullie website.',

    // Optionele knop "Direct een afspraak maken" in het ja-scherm.
    // Laat leeg om die knop te verbergen.
    appointmentUrl: '/uw-afspraak/',

    // Hoe lang de bezoeker minimaal op de site moet zijn voordat we de
    // pop-up scherp zetten (milliseconden). Voorkomt dat iemand die per
    // ongeluk klikt meteen een pop-up krijgt.
    //
    // Op 6 seconden gezet op basis van het Analytics-rapport van juli 2026:
    // bezoekers zijn gemiddeld 38 seconden actief en bekijken 1,98 pagina's,
    // dus grofweg 19 seconden per pagina. Met 8 seconden wachten was een
    // ruime derde van dat venster al voorbij voordat we begonnen te kijken.
    armAfterMs: 6000,

    // Hoe lang we na het vertreksignaal wachten voordat de pop-up verschijnt.
    // Komt de aanwijzer binnen die tijd terug in het venster, dan was het geen
    // vertrek maar een greep naar het menu bovenaan, en gebeurt er niets.
    //
    // Dit is de belangrijkste rem tegen een vervelende pop-up: het menu van de
    // site staat bovenaan, dus bezoekers bewegen daar constant naartoe en
    // schieten er soms voorbij. Een echte vertrekker komt niet terug.
    exitGraceMs: 400,

    // Wacht met scherpzetten tot de bezoeker iets gedaan heeft: bewegen,
    // scrollen, tikken of typen. Een echte bezoeker doet dat altijd binnen een
    // paar seconden; een geautomatiseerde bezoeker laadt de pagina en blijft
    // stilzitten. Dat scheelt vervuiling in het dashboard - in juli kwam 31%
    // van het verkeer uit landen zonder plausibele patiëntrelatie.
    requireInteraction: true,

    // Hoeveel dagen we iemand met rust laten nadat de pop-up getoond is.
    // Blijft op 7: van de bezoekers is 92% nieuw en vrijwel niemand komt terug,
    // dus deze grens raakt in de praktijk bijna niemand.
    cooldownDays: 7,

    // Pop-up ook op mobiel/tablet tonen? Daar bestaat geen muis, dus we
    // gebruiken een andere trigger (zie mobileIdleMs / snel omhoog scrollen).
    enableMobile: true,

    // Mobiel: na hoeveel milliseconden zonder enige interactie we de pop-up
    // tonen. Zet op 0 om deze trigger uit te schakelen.
    mobileIdleMs: 45000,

    // Pagina's waar de pop-up NOOIT moet verschijnen. Een term hoeft maar
    // ergens in het pad voor te komen, dus 'afspraak' dekt in één keer
    // '/uw-afspraak/', '/afspraak-chiro/', '/afspraak-fysio/' én
    // '/je-1e-afspraak/'. Schrijf de termen zonder schuine streep: '/afspraak'
    // zou '/je-1e-afspraak/' juist missen, omdat daar '-afspraak' staat.
    //
    // Deze lijst komt uit het Analytics-rapport, nagelopen door de praktijk.
    // Weggehaald: 'winkelwagen' en 'checkout', want die pagina's bestaan niet
    // (geen webshop, omzet 0). 'vacature' dekt /vacatures/: wie naar werk
    // zoekt, heeft niets aan de vraag of die gevonden heeft wat die zocht.
    //
    // Let op: het online boekingssysteem (Crossuite) staat op een ander domein,
    // dus daar draait dit script van zichzelf al niet.
    excludePaths: [
      'contact',
      'afspraak',
      'bedankt',
      'vacature'
    ],

    // Optionele hulplink onderin het nee-scherm, voor de vraag die het vaakst
    // onbeantwoord blijft. Uit het rapport: 18% van de zoekopdrachten op de
    // site zelf gaat over kosten, tarieven of vergoeding, terwijl die
    // informatie verspreid staat over zeven pagina's die samen maar 2,5% van
    // alle weergaven halen. Laat leeg om de link te verbergen.
    helpUrl: '/kosten-en-vergoedingen/',
    // Was een vraagzin toen dit nog een klein tekstlinkje onderaan was. Nu het
    // een knop is, hoort er een handeling op te staan.
    helpLabel: 'Kosten en vergoeding bekijken',

    // Vanaf het hoeveelste bezoek we iemand als terugkerend behandelen.
    // Zet op 0 om geen onderscheid te maken.
    //
    // Let op wat het rapport hierover zegt: 92% van de bezoekers is nieuw en de
    // retentie is vrijwel nul (van de 231 tot 599 bezoekers per week kwamen er
    // 2 tot 6 terug). Deze herkenning raakt dus maar een handvol mensen. Het
    // kost bijna niets en het cijfer is nuttig om te volgen, maar verwacht er
    // geen omzet van.
    returningFromVisit: 2,

    // Terugbelverzoek aan of uit.
    callbackOn: true,

    // Teksten. Pas gerust aan naar de toon van de praktijk.
    text: {
      question: 'Heeft u gevonden wat u zocht?',
      questionSub: 'We horen het graag - zo kunnen we de site verbeteren.',

      // Voor wie al eens eerder op de site was. Iemand die terugkomt is verder
      // in zijn overweging, dus die spreken we directer aan.
      questionReturning: 'Kunnen we u ergens mee helpen?',
      questionSubReturning: 'U bent hier eerder geweest - stelt u de vraag gerust rechtstreeks.',
      yes: 'Ja, gelukt',
      no: 'Nee, nog niet',

      yesTitle: 'Fijn om te horen!',
      yesBody: 'Bedankt voor uw bezoek. Tot ziens in de praktijk.',
      appointmentLabel: 'Direct een afspraak maken',

      // Tussenstap na "nee". Zonder deze vraag weten we alleen dát iemand niets
      // kon vinden, niet wat. In de eerste 30 dagen vertrokken 35 van de 37
      // mensen zonder ergens op te klikken - van die 35 wisten we dus niets.
      // Een reden aantikken kost bijna niets, en levert wel het lijstje op
      // waar je de site echt mee kunt verbeteren.
      reasonTitle: 'Waar ging uw vraag over?',
      reasonSub: 'Dan wijzen we u meteen de goede kant op.',
      reasonCosts: 'Kosten of vergoeding',
      reasonComplaint: 'Een klacht of behandeling',
      reasonAppointment: 'Een afspraak maken',
      reasonOther: 'Iets anders',

      // Terugbelverzoek: de enige uitweg waarbij de bezoeker niets hoeft te
      // durven. Nul van de 37 mensen belde uit zichzelf; een nummer
      // achterlaten kost drie seconden en kan buiten openingstijden.
      callbackLabel: 'Wij bellen u terug',
      directLabel: 'of neem direct contact op',
      callbackTitle: 'Dan bellen wij u',
      callbackBody: 'Laat uw naam en nummer achter. We bellen u terug, meestal nog dezelfde werkdag.',
      callbackName: 'Uw naam',
      callbackPhone: 'Uw telefoonnummer',
      callbackSend: 'Bel mij terug',
      callbackNote: 'We bewaren alleen uw naam en nummer, en gebruiken die om u terug te bellen.',
      callbackOk: 'Genoteerd',
      callbackOkBody: 'We bellen u zo snel mogelijk terug. Tot straks.',
      callbackError: 'Dat lukte niet. Probeert u het opnieuw, of bel ons gerust.',

      noTitle: 'Dat lossen we even op',
      // Noemde eerst alleen bellen. Dat sloot niet aan bij wat bezoekers doen:
      // die plannen liever zelf een afspraak dan dat ze de telefoon pakken.
      noBody: 'Plan gerust direct een afspraak, of stel uw vraag - we denken graag met u mee.',
      callLabel: 'Bel',
      whatsappLabel: 'Stuur een WhatsApp',
      hours: 'Maandag t/m vrijdag bereikbaar tijdens openingstijden.',

      close: 'Sluiten'
    }
  };

  /* ==========================================================================
     Vanaf hier hoef je in principe niets meer te wijzigen.
     ========================================================================== */

  // Wordt door de WordPress-plugin gevuld met het meetpunt en de instellingen.
  // Buiten WordPress blijft dit leeg en gelden de standaardwaarden hierboven.
  var SETTINGS = window.CF_EXIT_POPUP || {};

  // De instellingen uit WordPress over de standaardwaarden heen leggen. De
  // teksten zitten een niveau dieper, dus die mengen we apart - anders zou één
  // aangepaste zin alle andere teksten wissen.
  var CONFIG = (function () {
    var uit = {};
    var sleutel;

    for (sleutel in DEFAULTS) {
      if (Object.prototype.hasOwnProperty.call(DEFAULTS, sleutel)) {
        uit[sleutel] = DEFAULTS[sleutel];
      }
    }

    var eigen = SETTINGS.config;
    if (!eigen) return uit;

    for (sleutel in eigen) {
      if (!Object.prototype.hasOwnProperty.call(eigen, sleutel)) continue;
      if (sleutel === 'text') continue;
      if (eigen[sleutel] === null || eigen[sleutel] === undefined) continue;
      uit[sleutel] = eigen[sleutel];
    }

    if (eigen.text) {
      var teksten = {};
      for (sleutel in DEFAULTS.text) {
        if (Object.prototype.hasOwnProperty.call(DEFAULTS.text, sleutel)) {
          teksten[sleutel] = DEFAULTS.text[sleutel];
        }
      }
      for (sleutel in eigen.text) {
        if (Object.prototype.hasOwnProperty.call(eigen.text, sleutel) && eigen.text[sleutel]) {
          teksten[sleutel] = eigen.text[sleutel];
        }
      }
      uit.text = teksten;
    }

    return uit;
  })();

  var STORAGE_KEY = 'cf_exit_popup_shown_at';
  var VISITS_KEY = 'cf_exit_popup_visits';
  var LAST_SEEN_KEY = 'cf_exit_popup_last_seen';

  // Na een half uur zonder activiteit geldt een volgend bezoek als nieuw.
  var VISIT_TIMEOUT_MS = 30 * 60 * 1000;
  var shown = false;
  var armed = false;
  var idleTimer = null;
  var exitTimer = null;
  var visitCount = 1;
  var lastFocused = null;
  var root = null;

  // Welk scherm er nu staat: 'ask', 'reason', 'yes' of 'no'. Gaat mee bij het
  // sluiten, zodat we zien waar iemand afhaakte.
  var huidigeStap = 'ask';

  // Waar de vraag over ging, als de bezoeker dat heeft aangetikt.
  var gekozenReden = '';

  // Wanneer het terugbelformulier geopend werd. Een invulrobot is binnen een
  // seconde klaar; een mens niet.
  var formulierGeopendOp = 0;
  var bezigMetVersturen = false;

  // Willekeurige code per vertoning, zodat het dashboard de gebeurtenissen van
  // één bezoek aan elkaar kan knopen. Bevat geen enkel persoonsgegeven en
  // wordt nergens bewaard nadat het bezoek voorbij is.
  var sessionId = (function () {
    var s = '';
    var chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    for (var i = 0; i < 16; i++) {
      s += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return s;
  })();

  /* --- Hulpfuncties ------------------------------------------------------- */

  function isTouchDevice() {
    return window.matchMedia && window.matchMedia('(hover: none), (pointer: coarse)').matches;
  }

  // localStorage kan gooien in private mode of met strenge browserinstellingen.
  function storageGet(key) {
    try {
      return window.localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  }

  function storageSet(key, value) {
    try {
      window.localStorage.setItem(key, value);
    } catch (e) {
      /* niets aan te doen, we tonen de pop-up dan hooguit nog een keer */
    }
  }

  /**
   * Houdt bij hoeveel keer deze browser de site bezocht heeft, en geeft dat
   * aantal terug.
   *
   * Er wordt één getal bewaard, niets meer: geen datums per bezoek, geen
   * bekeken pagina's, geen kenmerk waarmee iemand te identificeren is. De
   * sessieteller zorgt dat doorklikken binnen één bezoek niet meetelt.
   *
   * Belangrijke beperking: dit werkt per browser. Wie eerst op de telefoon
   * kijkt en later op de laptop, telt twee keer als nieuw. Wie in een privé-
   * venster zit of zijn gegevens wist, begint weer bij 1. Verder komen zonder
   * inlog kan alleen met technieken die bezoekers over apparaten heen volgen,
   * en dat is precies wat we hier niet doen.
   */
  function countVisit() {
    var visits = parseInt(storageGet(VISITS_KEY) || '0', 10);
    var lastSeen = parseInt(storageGet(LAST_SEEN_KEY) || '0', 10);
    var now = Date.now();

    // Een bezoek loopt door zolang er activiteit is, en geldt als afgesloten na
    // een half uur stilte. Dat is dezelfde grens die Google Analytics gebruikt,
    // zodat de cijfers hier en daar over hetzelfde gaan.
    //
    // Bewust niet via sessionStorage: dat hoort bij één tabblad, dus wie drie
    // pagina's in drie tabbladen opent zou als drie bezoeken tellen.
    if (!lastSeen || now - lastSeen > VISIT_TIMEOUT_MS) {
      visits += 1;
      storageSet(VISITS_KEY, String(visits));
    }

    storageSet(LAST_SEEN_KEY, String(now));

    return visits;
  }

  function isReturning() {
    return CONFIG.returningFromVisit > 0 && visitCount >= CONFIG.returningFromVisit;
  }

  function inCooldown() {
    var stamp = parseInt(storageGet(STORAGE_KEY) || '0', 10);
    if (!stamp) return false;
    var days = (Date.now() - stamp) / 86400000;
    return days < CONFIG.cooldownDays;
  }

  function onExcludedPage() {
    var path = window.location.pathname.toLowerCase();
    return CONFIG.excludePaths.some(function (p) {
      return path.indexOf(p.toLowerCase()) !== -1;
    });
  }

  // Stuurt de gebeurtenis naar het eigen dashboard in WordPress.
  //
  // sendBeacon is hier belangrijk: die blijft ook werken als de bezoeker de
  // pagina op datzelfde moment verlaat, en dat is precies het scenario waar
  // deze pop-up voor gemaakt is. Waar sendBeacon ontbreekt vallen we terug op
  // fetch met keepalive.
  function report(action, detail) {
    if (!SETTINGS.endpoint) return;

    var body = JSON.stringify({
      sid: sessionId,
      type: action,
      page: window.location.pathname,
      device: isTouchDevice() ? 'mobiel' : 'desktop',
      trigger: detail.trigger || '',
      answer: detail.answer || '',
      // Bij het sluiten: op welk scherm de bezoeker toen stond.
      step: detail.step || '',
      // Waar de vraag over ging, zodra de bezoeker dat heeft aangetikt.
      reason: detail.reason || gekozenReden || '',
      // Alleen 'nieuw' of 'terugkerend', nooit het precieze aantal bezoeken.
      // Een teller van bijvoorbeeld 47 zou een browser onderscheidend maken.
      visitor: isReturning() ? 'terugkerend' : 'nieuw'
    });

    try {
      if (navigator.sendBeacon) {
        navigator.sendBeacon(SETTINGS.endpoint, new Blob([body], { type: 'application/json' }));
        return;
      }
      window.fetch(SETTINGS.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: body,
        keepalive: true
      });
    } catch (e) {
      /* meten mag nooit de pagina stukmaken */
    }
  }

  // Meldt gebeurtenissen aan het eigen dashboard, aan Google Analytics/Tag
  // Manager als die aanwezig is, en aan de pagina zelf zodat je er eigen
  // scripts op kunt hangen.
  function track(action, detail) {
    var payload = detail || {};
    report(action, payload);

    if (window.dataLayer && typeof window.dataLayer.push === 'function') {
      window.dataLayer.push({ event: 'cf_exit_popup', cf_action: action, cf_detail: payload });
    }
    if (typeof window.gtag === 'function') {
      window.gtag('event', 'cf_exit_popup_' + action, payload);
    }
    try {
      window.dispatchEvent(new CustomEvent('cf-exit-popup', { detail: { action: action, data: payload } }));
    } catch (e) {
      /* oude browsers zonder CustomEvent-constructor: niet erg */
    }
  }

  /* --- Opbouw van de pop-up ---------------------------------------------- */

  // De drie bakens bovenaan het venster. Per scherm een ander icoon, zodat je
  // in een oogopslag ziet waar je bent.
  var ICONEN = {
    vraag: '<path fill="none" stroke="currentColor" stroke-width="2.1" ' +
      'stroke-linecap="round" stroke-linejoin="round" ' +
      'd="M9.1 9a3 3 0 1 1 4.2 2.75c-.8.37-1.3 1.16-1.3 2.04v.46M12 17.5h.01"/>' +
      '<circle cx="12" cy="12" r="9.2" fill="none" stroke="currentColor" stroke-width="2.1"/>',

    goed: '<path fill="none" stroke="currentColor" stroke-width="2.6" ' +
      'stroke-linecap="round" stroke-linejoin="round" d="M20 6.5 9.4 17 4 11.7"/>',

    // Een gespreksballon, geen telefoon meer. Dit scherm leidt met een afspraak
    // en de kostenpagina; een telefoonhoorn erboven zou het tegenspreken.
    hulp: '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" ' +
      'stroke-linejoin="round" d="M20.5 11.7c0 4.3-3.8 7.8-8.5 7.8-1 0-2-.16-2.9-.45L4 20.5l1.3-4.2' +
      'a7.4 7.4 0 0 1-1.3-4.6C4 7.4 7.8 3.9 12.5 3.9s8 3.5 8 7.8Z"/>' +
      '<circle cx="9.3" cy="11.7" r="1.05" fill="currentColor"/>' +
      '<circle cx="12.5" cy="11.7" r="1.05" fill="currentColor"/>' +
      '<circle cx="15.7" cy="11.7" r="1.05" fill="currentColor"/>'
  };

  ICONEN.bellen = '<path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 ' +
    '1.1.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 ' +
    '1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.2 1l-2.3 2.2Z"/>';

  function baken(soort) {
    var extra = 'goed' === soort ? ' cf-exit__mark--goed' : '';

    return '<div class="cf-exit__mark' + extra + '" aria-hidden="true">' +
      '<svg viewBox="0 0 24 24" focusable="false">' + ICONEN[soort] + '</svg>' +
      '</div>';
  }

  function buildMarkup() {
    var t = CONFIG.text;
    var el = document.createElement('div');
    el.className = 'cf-exit';
    el.setAttribute('hidden', '');

    var appointmentBtn = CONFIG.appointmentUrl
      ? '<a class="cf-exit__btn cf-exit__btn--primary" href="' + CONFIG.appointmentUrl + '" data-cf="appointment">' +
        t.appointmentLabel + '</a>'
      : '';

    var whatsappBtn = CONFIG.whatsapp
      ? '<a class="cf-exit__btn cf-exit__btn--whatsapp" data-cf="whatsapp" rel="noopener" target="_blank" href="https://wa.me/' +
        CONFIG.whatsapp + '?text=' + encodeURIComponent(CONFIG.whatsappText) + '">' +
        '<svg class="cf-exit__icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
        '<path fill="currentColor" d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 0 0 4.79 1.22h.01c5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.82 9.82 0 0 0 12.04 2Zm0 18.13h-.01a8.2 8.2 0 0 1-4.19-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.22 8.22 0 0 1-1.26-4.36c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.27.86 5.83 2.42a8.19 8.19 0 0 1 2.41 5.83c0 4.54-3.7 8.21-8.24 8.21Zm4.52-6.16c-.25-.12-1.47-.72-1.69-.81-.23-.08-.39-.12-.56.13-.16.24-.64.8-.78.97-.14.16-.29.18-.54.06-.25-.13-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.43.13-.15.17-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.43h-.47c-.16 0-.43.06-.65.31-.22.25-.85.84-.85 2.04 0 1.2.87 2.36.99 2.53.12.16 1.71 2.61 4.14 3.66.58.25 1.03.4 1.38.51.58.19 1.11.16 1.53.1.47-.07 1.47-.6 1.67-1.18.21-.58.21-1.07.15-1.18-.06-.11-.22-.17-.47-.29Z"/>' +
        '</svg><span>' + t.whatsappLabel + '</span></a>'
      : '';

    el.innerHTML =
      '<div class="cf-exit__overlay" data-cf="overlay"></div>' +
      '<div class="cf-exit__dialog" role="dialog" aria-modal="true" aria-labelledby="cf-exit-title">' +
        '<button type="button" class="cf-exit__close" data-cf="close" aria-label="' + t.close + '">' +
          '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" width="20" height="20">' +
          '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M6 6l12 12M18 6L6 18"/></svg>' +
        '</button>' +

        // Logo van de praktijk, als er een is ingesteld in het dashboard.
        (CONFIG.logo
          ? '<img class="cf-exit__logo" src="' + CONFIG.logo + '" alt="" ' +
            'style="height:' + (CONFIG.logoHeight || 34) + 'px">'
          : '') +

        // Stap 1: de vraag. Terugkerende bezoekers krijgen een directere versie.
        '<div class="cf-exit__step" data-step="ask">' +
          baken('vraag') +
          '<h2 class="cf-exit__title" id="cf-exit-title">' +
            (isReturning() ? t.questionReturning : t.question) + '</h2>' +
          '<p class="cf-exit__body">' +
            (isReturning() ? t.questionSubReturning : t.questionSub) + '</p>' +
          '<div class="cf-exit__actions">' +
            '<button type="button" class="cf-exit__btn cf-exit__btn--ghost" data-cf="answer-yes">' + t.yes + '</button>' +
            '<button type="button" class="cf-exit__btn cf-exit__btn--primary" data-cf="answer-no">' + t.no + '</button>' +
          '</div>' +
        '</div>' +

        // Stap 2a: bezoeker heeft het gevonden
        '<div class="cf-exit__step" data-step="yes" hidden>' +
          baken('goed') +
          '<h2 class="cf-exit__title">' + t.yesTitle + '</h2>' +
          '<p class="cf-exit__body">' + t.yesBody + '</p>' +
          (appointmentBtn ? '<div class="cf-exit__actions">' + appointmentBtn + '</div>' : '') +
        '</div>' +

        // Stap 2b: eerst vragen waar de vraag over ging.
        //
        // Bewust vier brede knoppen en geen invoerveld: tikken kost een moment,
        // typen kost een besluit. En elk antwoord wordt meteen vastgelegd, dus
        // ook als iemand daarna alsnog wegklikt weten we wat die zocht.
        '<div class="cf-exit__step" data-step="reason" hidden>' +
          baken('vraag') +
          '<h2 class="cf-exit__title">' + t.reasonTitle + '</h2>' +
          '<p class="cf-exit__body">' + t.reasonSub + '</p>' +
          '<div class="cf-exit__actions cf-exit__actions--stack">' +
            '<button type="button" class="cf-exit__btn cf-exit__btn--ghost" data-cf="reason" data-reason="kosten">' +
              t.reasonCosts + '</button>' +
            '<button type="button" class="cf-exit__btn cf-exit__btn--ghost" data-cf="reason" data-reason="klacht">' +
              t.reasonComplaint + '</button>' +
            '<button type="button" class="cf-exit__btn cf-exit__btn--ghost" data-cf="reason" data-reason="afspraak">' +
              t.reasonAppointment + '</button>' +
            '<button type="button" class="cf-exit__btn cf-exit__btn--ghost" data-cf="reason" data-reason="anders">' +
              t.reasonOther + '</button>' +
          '</div>' +
        '</div>' +

        // Stap 2c: bezoeker heeft het niet gevonden -> hulp aanbieden.
        //
        // De volgorde hier is niet willekeurig. In de eerste 30 dagen zeiden 37
        // mensen "niet gevonden", kreeg ieder van hen een grote belknop te zien,
        // en klikte niemand erop - nul keer. Ondertussen start 19% van alle
        // sessies wel een online afspraak tegenover 1,26% die het nummer
        // aanklikt. Bellen is dus niet wat deze bezoekers willen.
        //
        // Daarom staat de afspraakknop nu bovenaan, is de kostenvraag een echte
        // knop geworden (18% van de zoekopdrachten op de site gaat daarover), en
        // is het telefoonnummer een leesbare regel in plaats van de grootste
        // knop op het scherm. Wie wil bellen kan dat nog steeds.
        '<div class="cf-exit__step" data-step="no" hidden>' +
          baken('hulp') +
          '<h2 class="cf-exit__title">' + t.noTitle + '</h2>' +
          '<p class="cf-exit__body">' + t.noBody + '</p>' +
          // Twee groepen, en dat onderscheid doet het werk.
          //
          // Boven: wat de vraag oplost. Daaronder het terugbelverzoek, met een
          // eigen omlijnde vorm zodat het als tweede echte keuze leest en niet
          // als restknop. Het stond eerst onderaan in vier grijze knoppen, en
          // dan zie je precies de optie niet die het meest oplevert.
          //
          // Onder de streep: de kanalen waarbij de bezoeker zelf moet bellen of
          // appen. Nuttig, maar niet waar we mee willen openen.
          '<div class="cf-exit__actions cf-exit__actions--stack" data-groep="hulp">' +
            appointmentBtn +
            (CONFIG.helpUrl
              ? '<a class="cf-exit__btn cf-exit__btn--ghost" data-cf="help" href="' + CONFIG.helpUrl + '">' +
                CONFIG.helpLabel + '</a>'
              : '') +
          '</div>' +
          (CONFIG.callbackOn
            ? '<div class="cf-exit__actions cf-exit__actions--stack">' +
              '<button type="button" class="cf-exit__btn cf-exit__btn--outline" data-cf="callback-open">' +
              t.callbackLabel + '</button></div>'
            : '') +
          (whatsappBtn
            ? '<p class="cf-exit__scheiding"><span>' + t.directLabel + '</span></p>' +
              '<div class="cf-exit__actions cf-exit__actions--stack">' + whatsappBtn + '</div>'
            : '') +
          '<p class="cf-exit__phone">' +
            '<a data-cf="call" href="tel:' + CONFIG.phoneHref + '">' +
              '<svg class="cf-exit__phoneicon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
              '<path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.2 1l-2.3 2.2Z"/>' +
              '</svg>' + t.callLabel + ' ' + CONFIG.phoneDisplay +
            '</a>' +
          '</p>' +
          '<p class="cf-exit__note">' + t.hours + '</p>' +
        '</div>' +

        // Stap 3: het terugbelverzoek.
        //
        // Twee velden, meer niet. We vragen met opzet niet waar de vraag over
        // gaat: zou iemand daar een klacht invullen, dan staat er een
        // gezondheidsgegeven in de database van een marketingtool. Het
        // onderwerp kennen we al grofweg uit de vorige stap.
        '<div class="cf-exit__step" data-step="callback" hidden>' +
          baken('bellen') +
          '<h2 class="cf-exit__title">' + t.callbackTitle + '</h2>' +
          '<p class="cf-exit__body">' + t.callbackBody + '</p>' +
          '<form class="cf-exit__form" data-cf="callback-form" novalidate>' +
            '<label class="cf-exit__veld">' +
              '<span class="cf-exit__label">' + t.callbackName + '</span>' +
              '<input type="text" name="naam" autocomplete="name" required>' +
            '</label>' +
            '<label class="cf-exit__veld">' +
              '<span class="cf-exit__label">' + t.callbackPhone + '</span>' +
              '<input type="tel" name="telefoon" autocomplete="tel" inputmode="tel" required>' +
            '</label>' +
            // Onzichtbaar voor mensen, aantrekkelijk voor invulrobots.
            '<div class="cf-exit__val" aria-hidden="true">' +
              '<label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>' +
            '</div>' +
            '<p class="cf-exit__fout" data-cf="callback-fout" role="alert" hidden></p>' +
            '<button type="submit" class="cf-exit__btn cf-exit__btn--primary">' +
              t.callbackSend + '</button>' +
          '</form>' +
          '<p class="cf-exit__note">' + t.callbackNote + '</p>' +
        '</div>' +

        // Stap 4: bevestiging.
        '<div class="cf-exit__step" data-step="callback-ok" hidden>' +
          baken('goed') +
          '<h2 class="cf-exit__title">' + t.callbackOk + '</h2>' +
          '<p class="cf-exit__body">' + t.callbackOkBody + '</p>' +
        '</div>' +
      '</div>';

    return el;
  }

  /* --- Openen, sluiten, focus -------------------------------------------- */

  function focusables() {
    return Array.prototype.filter.call(
      root.querySelectorAll('a[href], button:not([disabled])'),
      function (node) { return node.offsetParent !== null; }
    );
  }

  function trapFocus(e) {
    if (e.key !== 'Tab') return;
    var items = focusables();
    if (!items.length) return;
    var first = items[0];
    var last = items[items.length - 1];

    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  function onKeydown(e) {
    if (e.key === 'Escape') {
      close('escape');
      return;
    }
    trapFocus(e);
  }

  // Zet de knop die bij de gekozen reden hoort bovenaan, en geef hem het
  // hoofdaccent. Wie op "kosten" tikte, hoort geen afspraakknop als eerste te
  // zien - dan heb je de vraag wel gesteld maar er niets mee gedaan.
  function benadruk(reden) {
    if (!root) return;

    var rij = root.querySelector('[data-step="no"] [data-groep="hulp"]');
    if (!rij) return;

    var doel = 'kosten' === reden ? 'help'
      : ( 'klacht' === reden || 'afspraak' === reden ) ? 'appointment'
      : '';

    if (!doel) return;

    var knop = rij.querySelector('[data-cf="' + doel + '"]');
    if (!knop || knop === rij.firstChild) return;

    // De vorige hoofdknop wordt bijzaak, de nieuwe krijgt het accent.
    var vorige = rij.querySelector('.cf-exit__btn--primary');
    if (vorige && vorige !== knop) {
      vorige.classList.remove('cf-exit__btn--primary');
      vorige.classList.add('cf-exit__btn--ghost');
    }

    knop.classList.remove('cf-exit__btn--ghost');
    knop.classList.add('cf-exit__btn--primary');
    rij.insertBefore(knop, rij.firstChild);
  }

  function showStep(name) {
    // Onthouden waar de bezoeker is, zodat we bij het sluiten kunnen melden
    // welk scherm er stond. Zonder dat is "geen antwoord gegeven" één grote
    // bak waarin wegklikken en negeren niet te onderscheiden zijn.
    huidigeStap = name;

    Array.prototype.forEach.call(root.querySelectorAll('.cf-exit__step'), function (step) {
      var match = step.getAttribute('data-step') === name;
      if (match) {
        step.removeAttribute('hidden');
      } else {
        step.setAttribute('hidden', '');
      }
    });
    var target = root.querySelector('[data-step="' + name + '"] .cf-exit__btn');
    if (target) target.focus();
  }

  function open(trigger) {
    if (shown) return;
    shown = true;
    disarm();
    storageSet(STORAGE_KEY, String(Date.now()));

    // Altijd bij de vraag beginnen, ook als een vorige keer op een later
    // scherm geëindigd is.
    gekozenReden = '';
    showStep('ask');

    lastFocused = document.activeElement;
    root.removeAttribute('hidden');
    // Volgende frame, zodat de CSS-transitie daadwerkelijk afspeelt.
    requestAnimationFrame(function () {
      root.classList.add('is-open');
    });
    document.body.classList.add('cf-exit-lock');
    document.addEventListener('keydown', onKeydown, true);

    var firstBtn = root.querySelector('[data-step="ask"] .cf-exit__btn');
    if (firstBtn) firstBtn.focus();

    track('open', { trigger: trigger });
  }

  function close(reason) {
    root.classList.remove('is-open');
    document.body.classList.remove('cf-exit-lock');
    document.removeEventListener('keydown', onKeydown, true);

    window.setTimeout(function () {
      root.setAttribute('hidden', '');
    }, 220);

    if (lastFocused && typeof lastFocused.focus === 'function') {
      lastFocused.focus();
    }
    track('close', { reason: reason, step: huidigeStap });
  }

  /* --- Triggers ----------------------------------------------------------- */

  // Desktop: de muis verlaat het venster aan de bovenkant (richting tabbladen,
  // adresbalk of de sluitknop). relatedTarget is dan leeg.
  //
  // We wachten daarna nog exitGraceMs af. Wie naar het menu bovenaan reikt en
  // er net voorbij schiet, is binnen een fractie van een seconde weer terug -
  // en krijgt dus niets te zien. Wie echt weggaat, komt niet terug.
  function onMouseOut(e) {
    if (!armed || shown || exitTimer) return;
    if (e.relatedTarget || e.clientY > 0) return;

    if (!CONFIG.exitGraceMs) {
      open('mouseleave');
      return;
    }

    exitTimer = window.setTimeout(function () {
      exitTimer = null;
      open('mouseleave');
    }, CONFIG.exitGraceMs);
  }

  // De aanwijzer is terug in het venster: het was een valse start.
  function onMouseBack() {
    if (!exitTimer) return;

    window.clearTimeout(exitTimer);
    exitTimer = null;

    // Alleen voor de testpagina en eigen scripts; hier gaat niets naar de
    // server, want een valse start is geen gebeurtenis om te bewaren.
    try {
      window.dispatchEvent(new CustomEvent('cf-exit-popup', {
        detail: { action: 'valse-start', data: {} }
      }));
    } catch (e) {
      /* oude browsers: niet erg */
    }
  }

  // Mobiel: geen inactiviteit meer -> timer opnieuw starten.
  function resetIdle() {
    if (!armed || shown || !CONFIG.mobileIdleMs) return;
    window.clearTimeout(idleTimer);
    idleTimer = window.setTimeout(function () {
      open('idle');
    }, CONFIG.mobileIdleMs);
  }

  // Mobiel: snel omhoog scrollen richting de bovenkant is vaak een teken dat
  // iemand naar de adresbalk of terugknop gaat.
  var lastScrollY = 0;
  var lastScrollT = 0;
  function onScroll() {
    if (!armed || shown) return;
    var y = window.pageYOffset;
    var now = Date.now();
    var dt = now - lastScrollT;

    if (dt > 0 && dt < 500) {
      var speed = (lastScrollY - y) / dt; // pixels per ms, positief = omhoog
      if (speed > 1.2 && y < 300) {
        open('scroll-up');
      }
    }
    lastScrollY = y;
    lastScrollT = now;
    resetIdle();
  }

  // Wacht op het eerste teken van leven en zet daarna scherp. Zonder enige
  // interactie gebeurt er niets - zo blijven bezoekers die de pagina alleen
  // ophalen en verder niets doen buiten de metingen.
  var WAKE_EVENTS = ['mousemove', 'scroll', 'keydown', 'touchstart', 'click'];
  var stopWaiting = null;

  function armWhenInteracted() {
    function go() {
      stopWaiting();
      if (shown) return;
      arm();
    }

    stopWaiting = function () {
      WAKE_EVENTS.forEach(function (evt) {
        window.removeEventListener(evt, go, true);
      });
      stopWaiting = null;
    };

    WAKE_EVENTS.forEach(function (evt) {
      window.addEventListener(evt, go, { passive: true, capture: true });
    });
  }

  function arm() {
    armed = true;
    if (isTouchDevice()) {
      if (!CONFIG.enableMobile) return;
      ['touchstart', 'click', 'keydown'].forEach(function (evt) {
        document.addEventListener(evt, resetIdle, { passive: true });
      });
      window.addEventListener('scroll', onScroll, { passive: true });
      resetIdle();
    } else {
      document.addEventListener('mouseout', onMouseOut);
      // mouseover vuurt zodra de aanwijzer weer boven de pagina komt.
      document.addEventListener('mouseover', onMouseBack);
    }
  }

  function disarm() {
    armed = false;
    if (stopWaiting) stopWaiting();
    window.clearTimeout(idleTimer);
    window.clearTimeout(exitTimer);
    exitTimer = null;
    document.removeEventListener('mouseout', onMouseOut);
    document.removeEventListener('mouseover', onMouseBack);
    window.removeEventListener('scroll', onScroll);
    ['touchstart', 'click', 'keydown'].forEach(function (evt) {
      document.removeEventListener(evt, resetIdle);
    });
  }

  /* --- Start -------------------------------------------------------------- */

  // Verstuurt het terugbelverzoek.
  //
  // Hier gebruiken we bewust géén sendBeacon: dat vertelt niet of het gelukt
  // is, en juist hier moet de bezoeker een bevestiging krijgen. Iemand die zijn
  // nummer achterlaat en niets terugziet, gaat ervan uit dat het mislukt is.
  function verstuurTerugbelverzoek(form) {
    if (bezigMetVersturen) return;

    var foutvak = root.querySelector('[data-cf="callback-fout"]');
    var knop = form.querySelector('button[type="submit"]');

    function toonFout(bericht) {
      if (!foutvak) return;
      foutvak.textContent = bericht;
      foutvak.hidden = false;
    }

    if (foutvak) foutvak.hidden = true;

    var naam = String(form.naam.value || '').trim();
    var telefoon = String(form.telefoon.value || '').trim();

    if (!naam || !telefoon) {
      toonFout(CONFIG.text.callbackError);
      return;
    }

    if (!SETTINGS.callbackEndpoint) {
      // Buiten WordPress (demo, testpagina) is er niets om naartoe te sturen.
      showStep('callback-ok');
      return;
    }

    bezigMetVersturen = true;
    if (knop) knop.disabled = true;

    window.fetch(SETTINGS.callbackEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: naam,
        phone: telefoon,
        website: String(form.website.value || ''),
        elapsed: formulierGeopendOp ? Date.now() - formulierGeopendOp : 0,
        reason: gekozenReden,
        page: window.location.pathname
      })
    }).then(function (antwoord) {
      bezigMetVersturen = false;
      if (knop) knop.disabled = false;

      if (antwoord.ok || 204 === antwoord.status) {
        track('callback', { reason: gekozenReden });
        showStep('callback-ok');
        return;
      }

      toonFout(CONFIG.text.callbackError);
    }).catch(function () {
      bezigMetVersturen = false;
      if (knop) knop.disabled = false;
      toonFout(CONFIG.text.callbackError);
    });
  }

  function bindUi() {
    root.addEventListener('submit', function (e) {
      var form = e.target.closest ? e.target.closest('[data-cf="callback-form"]') : null;
      if (!form) return;
      e.preventDefault();
      verstuurTerugbelverzoek(form);
    });

    root.addEventListener('click', function (e) {
      var el = e.target.closest ? e.target.closest('[data-cf]') : null;
      if (!el) return;
      var action = el.getAttribute('data-cf');

      switch (action) {
        case 'overlay':
        case 'close':
          close(action);
          break;
        case 'answer-yes':
          track('answer', { answer: 'ja' });
          showStep('yes');
          break;
        case 'answer-no':
          track('answer', { answer: 'nee' });
          showStep('reason');
          break;
        case 'reason':
          gekozenReden = el.getAttribute('data-reason') || 'anders';
          track('reason', { reason: gekozenReden });
          benadruk(gekozenReden);
          showStep('no');
          break;
        case 'call':
          track('call', { number: CONFIG.phoneHref });
          break;
        case 'whatsapp':
          track('whatsapp', {});
          break;
        case 'help':
          track('help', {});
          break;
        case 'callback-open':
          formulierGeopendOp = Date.now();
          track('callback-open', {});
          showStep('callback');
          var eersteVeld = root.querySelector('[data-step="callback"] input[name="naam"]');
          if (eersteVeld) eersteVeld.focus();
          break;
        case 'appointment':
          track('appointment', {});
          break;
      }
    });
  }

  function init() {
    // Debug-modus: zet ?cf-popup=test in de URL om de cooldown te negeren en
    // de pop-up direct te kunnen testen.
    var testMode = window.location.search.indexOf('cf-popup=test') !== -1;

    if (!testMode) {
      if (inCooldown() || onExcludedPage()) return;
    }
    if (isTouchDevice() && !CONFIG.enableMobile) return;

    // Bezoek tellen voordat we de pop-up opbouwen, zodat de tekst meteen bij
    // het juiste soort bezoeker past.
    visitCount = countVisit();

    root = buildMarkup();
    document.body.appendChild(root);
    bindUi();

    if (testMode) {
      window.setTimeout(function () { open('test'); }, 500);
      return;
    }

    window.setTimeout(
      CONFIG.requireInteraction ? armWhenInteracted : arm,
      CONFIG.armAfterMs
    );
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Kleine publieke ingang, handig om te testen of om de pop-up aan een eigen
  // knop te hangen:
  //
  //   cfExitPopup.toon();     - toon hem meteen
  //   cfExitPopup.vergeet();  - wis het "al getoond"-geheugen
  window.cfExitPopup = {
    toon: function () {
      if (!root) {
        root = buildMarkup();
        document.body.appendChild(root);
        bindUi();
      }
      shown = false;
      open('handmatig');
    },
    vergeet: function () {
      try {
        window.localStorage.removeItem(STORAGE_KEY);
      } catch (e) {
        /* niets aan te doen */
      }

      // "Vergeten" betekent ook dat de pop-up weer mag verschijnen, dus zetten
      // we de herkenning opnieuw scherp. Zonder dit blijft hij na één keer
      // tonen definitief uit.
      shown = false;
      disarm();
      arm();
    }
  };
})();
